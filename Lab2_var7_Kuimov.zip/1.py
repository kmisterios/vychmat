from typing import List
import numpy as np
import math


# умножение матрицы на вектор
def multAx(a,b,c,x,n):
    m: List[float] = [0] * n
    for i in range(n):
        if (i > 0) and (i != n -1 ):
            m[i] = a[i-1]*x[i-1] + c[i]*x[i] + b[i]*x[i+1]
    m[0] = c[0]*x[0] + b[0]*x[1]
    m[n-1] = a[n-2]*x[n-2] + c[n-1]*x[n-1]

    return m

#умножение вектора на число
def pr(x,t):
    z: List[float] = [0] * n
    i = 0
    for elem in x:
        z[i] = elem * t
        i += 1
    return z

#разность двух векторов
def razn(x,y):
    z: List[float] = [0] * n
    i = 0
    for elem in x:
        z[i] = elem - y[i]
        i += 1
    return z
#сумма двух векторов
def sum(x,y):
    z: List[float] = [0] * n
    i = 0
    for elem in x:
        z[i] = elem + y[i]
        i += 1
    return z

n = 1000
#метод простых итераций с выбором итерационного параметра
f: List[float] = [0] * n
file = open('f7.txt')
i = 0
for line in file:
    f[i] = float(line)
    i += 1
file.close()

a: List[float] = [0] * (n - 1)
b: List[float] = [0] * (n - 1)
c: List[float] = [0] * n
A: List[List[float]] = [[0] * n for i in range(n)]
e: List[float] = [0] * n
for i in range(n-1):
    a[i] = -1
    b[i] = -1

alpha = 0.01
beta = 10
c[0] = beta + 2
for i in range(1,n):
    c[i] = alpha + 2

for i in range(n):
    for r in range(n):
        if (i == r) and (i != 0):
            A[i][r] = 2 + alpha
        if (i == r) and (i == 0):
            A[i][r] = 2 + beta
        if (i + 1 == r) or (i - 1 == r):
            A[i][r] = -1

for i in range(n):
        e[i] = 1
lamda = np.linalg.eigvals(A) #найдем собственные значения A
tau = 2/(np.min(lamda) + np.max(lamda)) #найдем оптимальное значение итерационного параметра
xn: List[float] = [0] * n
i = 0
xn = pr(f,tau)
r0: List[float] = [0] * n
r0 = razn(f, multAx(a,b,c,xn,n))
r: List[float] = [0] * n
x = razn(multAx(pr(a,-tau),pr(b,-tau),razn(e,pr(c,tau)),xn,n),pr(f,-tau))
r = razn(f, multAx(a,b,c,x,n))
k1 = 1
divr1: List[float] = [0] * 3635
k2: List[float] = [0] * 3635
while np.linalg.norm(r)/np.linalg.norm(r0) > 0.001:
    k2[k1] = k1
    divr1[k1] = np.linalg.norm(r)/np.linalg.norm(r0)
    xn = x
    x = razn(multAx(pr(a,-tau),pr(b,-tau),razn(e,pr(c,tau)),xn,n), pr(f, -tau))
    r = razn(f, multAx(a,b,c, x, n))
    k1+=1

fi3 = open('x17.txt', 'w')
for i in range(n):
        fi3.write('%e' % x[i] + "\n")
fi3.close()

###############################################################
#метод прогонки
alpha1: List[float] = [0] * (n-1)
beta1: List[float] = [0] * n
alpha1[0] = b[0]/c[0]
beta1[0] = f[0]/c[0]
for i in range(n-2):
    if i == 0:
        continue
    beta1[i] = (f[i] - beta1[i - 1] * a[i-1])/(c[i] - alpha1[i - 1] * a[i-1])
    alpha1[i] = b[i]/(c[i] - alpha1[i - 1] * a[i-1])
beta1[n - 1] =(f[n-1] - beta1[n-1 - 1] * a[n-2])/(c[n-1] - alpha1[n-1 - 1] * a[n-2])
x1: List[float] = [0] * n
x1[n-1] = beta1[n-1]
i = n - 1
while i > 0:
    x1[i-1] = beta1[i-1] - x1[i]*alpha1[i-1]
    i -= 1

fi4 = open('x7(progonka).txt', 'w')
for i in range(n):
        fi4.write('%e' % x1[i] + "\n")
fi4.close()


##############################################
#метод простых итераций БЕЗ выбора итерационного параметра с диагональным предобуславливателем
zero: List[float] = [0] * n
d: List[float] = [0] * n
for i in range(n):#будем задавать матрицу D^{-1} ее диагональю
    d[i] = 1/c[i]
xp: List[float] = [0] * n
xp = multAx(zero,zero,d,f,n)
ro: List[float] = [0] * n
ro = razn(f,multAx(a,b,c,xp,n))
xx: List[float] = [0] * n
b1: List[float] = [0] * (n - 1)
a1: List[float] = [0] * (n - 1)
for i in range(n - 1):
    b1[i] = d[i]
for i in range(n - 1):
    a1[i] = d[i+1]
xx =sum(multAx(a1,b1,zero,xp,n),multAx(zero,zero,d,f,n))
r1: List[float] = [0] * (n - 1)
divr: List[float] = [0] * 4*n
k: List[float] = [0] * 4*n
r1 = razn(f,multAx(a,b,c,xx,n))
k[0] = 0
k1 = 1
while np.linalg.norm(r1)/np.linalg.norm(ro) > 0.001:
    k[k1] = k1
    divr[k1] = np.linalg.norm(r1)/np.linalg.norm(ro)
    xp = xx
    xx = sum(multAx(a1,b1,zero,xp,n),multAx(zero,zero,d,f,n))
    r1 = razn(f,multAx(a,b,c,xx,n))
    k1 += 1


fi4 = open('x27.txt', 'w')
for i in range(n):
        fi4.write('%e' % xx[i] + "\n")
fi4.close()

