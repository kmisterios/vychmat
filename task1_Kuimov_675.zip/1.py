from typing import List


def LU(A):
    for k in range(2):
        for i in range(3):
            for j in range(3):
                if (j == k) and (j < i):
                    A[i][j] = A[i][j] / A[k][k]
                if (i > k) and (j > k):
                    A[i][j] = A[i][j] - A[i][k] * A[k][j]
    return A


n = 3
A1: List[List[int]] = [[0] * n for i in range(n)]
file1 = open('A7.txt')
i, j = 0, 0
for line in file1:
    A1[i][j] = float(line)
    i += 1
    if i == 3:
        j += 1
        i = 0
file1.close()
file2 = open('f7.txt')
f: List[int] = [0, 0, 0]
i = 0
for line in file2:
    f[i] = float(line)
    i += 1
file2.close()
A2 = LU(A1)
n = 3
L = [[0] * n for i in range(n)]
U = [[0] * n for i in range(n)]
for i in range(3):
    for j in range(3):
        if i == j:
            L[i][i] = 1
            U[i][j] = A2[i][j]
        if i > j:
            L[i][j] = A2[i][j]
            U[i][j] = 0
        if i < j:
            U[i][j] = A2[i][j]
            L[i][j] = 0
fi1 = open('L7.txt', 'w')
for i in range(3):
    for j in range(3):
        fi1.write('%e' % L[j][i] + "\n")
fi1.close()
fi2 = open('U7.txt', 'w')
for i in range(3):
    for j in range(3):
        fi2.write('%e' % U[j][i] + "\n")
fi2.close()
y1 = f[0]
y2 = (f[1] - L[1][0] * y1)
y3 = (f[2] - L[2][0] * y1 - L[2][1] * y2)
y: List[int] = [y1, y2, y3]
x3 = y[2] / U[2][2]
x2 = (y[1] - U[1][2] * x3) / U[1][1]
x1 = (y[0] - U[0][2] * x3 - U[0][1] * x2) / U[0][0]
x: List[int] = [x1, x2, x3]
fi3 = open('x7.txt', 'w')
for i in range(3):
        fi3.write('%e' % x[i] + "\n")
fi3.close()

