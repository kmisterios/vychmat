from typing import List


n = 1000
a: List[float] = [0] * (n - 1)
b: List[float] = [0] * (n - 1)
c: List[float] = [0] * n
r: List[float] = [0] * n
file1 = open('a_diag7.txt')
i = 0
for line in file1:
    a[i] = float(line)
    i += 1
file1.close()
file2 = open('b_diag7.txt')
i = 0
for line in file2:
    b[i] = float(line)
    i += 1
file2.close()
file3 = open('c_diag7.txt')
i = 0
for line in file3:
    c[i] = float(line)
    i += 1
file3.close()
file4 = open('r7.txt')
i = 0
for line in file4:
    r[i] = float(line)
    i += 1
file4.close()
alpha: List[float] = [0] * (n-1)
beta: List[float] = [0] * n
alpha[0] = b[0]/c[0]
beta[0] = r[0]/c[0]
for i in range(n-2):
    if i == 0:
        continue
    beta[i] = (r[i] - beta[i - 1] * a[i-1])/(c[i] - alpha[i - 1] * a[i-1])
    alpha[i] = b[i]/(c[i] - alpha[i - 1] * a[i-1])
beta[n - 1] =(r[n-1] - beta[n-1 - 1] * a[n-2])/(c[n-1] - alpha[n-1 - 1] * a[n-2])
fi1 = open('alpha7.txt', 'w')
for i in range(n-1):
        fi1.write('%e' % alpha[i] + "\n")
fi1.close()
fi2 = open('beta7.txt', 'w')
for i in range(n):
        fi2.write('%e' % beta[i] + "\n")
fi2.close()
x: List[float] = [0] * n
x[n-1] = beta[n-1]
i = n - 1
while i > 0:
    x[i-1] = beta[i-1] - x[i]*alpha[i-1]
    i -= 1
fi3 = open('x7.txt', 'w')
for i in range(n):
        fi3.write('%e' % x[i] + "\n")
fi3.close()
